import React from 'react';
import { Link } from 'react-router-dom';
import { ChevronRight, Flower, Palette, Hammer, Scissors, Wind, Droplets } from 'lucide-react';
import Section from '../ui/Section';
import { services } from '../../data/services';

const iconMap: { [key: string]: React.ReactNode } = {
  'palette': <Palette size={24} className="text-green-700" />,
  'flower': <Flower size={24} className="text-green-700" />,
  'scissors': <Scissors size={24} className="text-green-700" />,
  'hammer': <Hammer size={24} className="text-green-700" />,
  'droplets': <Droplets size={24} className="text-green-700" />,
  'wind': <Wind size={24} className="text-green-700" />,
};

const FeaturedServices: React.FC = () => {
  return (
    <Section
      id="services"
      title="Our Services"
      subtitle="We offer a comprehensive range of landscaping services to meet all your outdoor needs."
    >
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
        {services.map((service) => (
          <div
            key={service.id}
            className="bg-white rounded-lg shadow-md overflow-hidden transition-transform hover:-translate-y-1 hover:shadow-lg"
          >
            <div className="h-48 overflow-hidden">
              <img
                src={service.image}
                alt={service.title}
                className="w-full h-full object-cover transition-transform hover:scale-105"
              />
            </div>
            <div className="p-6">
              <div className="flex items-center mb-3">
                {iconMap[service.icon]}
                <h3 className="text-xl font-bold ml-2">{service.title}</h3>
              </div>
              <p className="text-gray-600 mb-4">{service.description}</p>
              <Link
                to={`/services#${service.id}`}
                className="inline-flex items-center text-green-700 font-medium hover:text-green-800"
              >
                Learn more
                <ChevronRight size={16} className="ml-1" />
              </Link>
            </div>
          </div>
        ))}
      </div>

      <div className="text-center mt-12">
        <Link
          to="/services"
          className="inline-flex items-center px-6 py-3 bg-green-700 text-white rounded-md hover:bg-green-800 transition-colors font-medium"
        >
          View All Services
          <ChevronRight size={16} className="ml-1" />
        </Link>
      </div>
    </Section>
  );
};

export default FeaturedServices;