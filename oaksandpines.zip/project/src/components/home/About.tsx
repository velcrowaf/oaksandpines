import React from 'react';
import { Award, CheckCircle, Users } from 'lucide-react';
import Section from '../ui/Section';

const About: React.FC = () => {
  return (
    <Section id="about">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
        <div>
          <h2 className="text-3xl font-bold mb-6 text-gray-800">
            Premium Landscaping Services Since 2005
          </h2>
          <p className="text-gray-600 mb-6">
            Oaks And Pines Landscaping Ltd is a premium landscaping company dedicated to creating beautiful, 
            functional outdoor spaces for residential and commercial clients. With over 18 years of experience, 
            our team of skilled designers and landscapers work closely with each client to bring their vision to life.
          </p>
          <p className="text-gray-600 mb-8">
            We pride ourselves on sustainable practices, attention to detail, and exceptional customer service. 
            From concept to completion, we're committed to exceeding your expectations and transforming your 
            outdoor space into a stunning landscape that enhances your property and lifestyle.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="flex flex-col items-center text-center p-4 border border-gray-200 rounded-lg">
              <Award size={32} className="text-green-700 mb-2" />
              <h3 className="font-bold">Award Winning</h3>
              <p className="text-sm text-gray-600">Recognized excellence</p>
            </div>
            <div className="flex flex-col items-center text-center p-4 border border-gray-200 rounded-lg">
              <CheckCircle size={32} className="text-green-700 mb-2" />
              <h3 className="font-bold">Certified Experts</h3>
              <p className="text-sm text-gray-600">Professional team</p>
            </div>
            <div className="flex flex-col items-center text-center p-4 border border-gray-200 rounded-lg">
              <Users size={32} className="text-green-700 mb-2" />
              <h3 className="font-bold">500+ Clients</h3>
              <p className="text-sm text-gray-600">Trusted by many</p>
            </div>
          </div>
        </div>
        
        <div className="relative">
          <img
            src="https://images.pexels.com/photos/4195342/pexels-photo-4195342.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
            alt="Landscaping professionals at work"
            className="rounded-lg shadow-xl w-full h-auto object-cover"
          />
          <div className="absolute -bottom-6 -left-6 bg-white p-4 rounded-lg shadow-lg">
            <p className="text-green-700 font-bold text-lg">18+ Years</p>
            <p className="text-gray-700">of Experience</p>
          </div>
        </div>
      </div>
    </Section>
  );
};

export default About;