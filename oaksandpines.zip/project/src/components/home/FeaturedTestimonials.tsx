import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { ChevronLeft, ChevronRight, Quote } from 'lucide-react';
import Section from '../ui/Section';
import { testimonials } from '../../data/testimonials';

const FeaturedTestimonials: React.FC = () => {
  const [activeIndex, setActiveIndex] = useState(0);

  const nextTestimonial = () => {
    setActiveIndex((prev) => (prev === testimonials.length - 1 ? 0 : prev + 1));
  };

  const prevTestimonial = () => {
    setActiveIndex((prev) => (prev === 0 ? testimonials.length - 1 : prev - 1));
  };

  return (
    <Section
      id="testimonials"
      title="What Our Clients Say"
      subtitle="Don't just take our word for it - hear from our satisfied clients."
    >
      <div className="max-w-5xl mx-auto relative">
        <div className="absolute -top-12 left-1/2 transform -translate-x-1/2 text-green-600 opacity-20">
          <Quote size={80} />
        </div>

        <div className="bg-white rounded-xl shadow-xl p-8 relative z-10">
          <div className="flex flex-col items-center text-center">
            <img
              src={testimonials[activeIndex].avatar}
              alt={testimonials[activeIndex].name}
              className="w-20 h-20 object-cover rounded-full border-4 border-green-100 mb-6"
            />
            
            <p className="text-xl text-gray-700 italic mb-6 max-w-3xl">
              "{testimonials[activeIndex].content}"
            </p>
            
            <div className="mb-8">
              <h4 className="font-bold text-lg text-gray-900">
                {testimonials[activeIndex].name}
              </h4>
              <p className="text-gray-600">{testimonials[activeIndex].role}</p>
            </div>
            
            <div className="flex space-x-3">
              <button
                onClick={prevTestimonial}
                className="w-10 h-10 rounded-full flex items-center justify-center border border-gray-300 text-gray-600 hover:bg-green-100 hover:border-green-500 transition-colors"
                aria-label="Previous testimonial"
              >
                <ChevronLeft size={20} />
              </button>
              <button
                onClick={nextTestimonial}
                className="w-10 h-10 rounded-full flex items-center justify-center border border-gray-300 text-gray-600 hover:bg-green-100 hover:border-green-500 transition-colors"
                aria-label="Next testimonial"
              >
                <ChevronRight size={20} />
              </button>
            </div>
          </div>
        </div>
        
        <div className="text-center mt-12">
          <Link
            to="/testimonials"
            className="inline-flex items-center px-6 py-3 bg-green-700 text-white rounded-md hover:bg-green-800 transition-colors font-medium"
          >
            Read More Testimonials
            <ChevronRight size={16} className="ml-1" />
          </Link>
        </div>
      </div>
    </Section>
  );
};

export default FeaturedTestimonials;