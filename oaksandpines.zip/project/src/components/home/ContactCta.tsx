import React from 'react';
import { Link } from 'react-router-dom';
import { Phone } from 'lucide-react';
import Button from '../ui/Button';

const ContactCta: React.FC = () => {
  return (
    <section className="py-16 bg-gradient-to-r from-green-700 to-green-900 text-white">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Ready to Transform Your Outdoor Space?
          </h2>
          <p className="text-xl text-green-100 mb-8 max-w-2xl mx-auto">
            Contact us today for a free consultation and take the first step toward creating the landscape of your dreams.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Link to="/booking">
              <Button size="lg" variant="secondary" className="min-w-44">
                Book Consultation
              </Button>
            </Link>
            <a href="tel:+15551234567" className="inline-flex items-center justify-center px-6 py-3 bg-white text-green-800 rounded-md hover:bg-gray-100 transition-colors font-medium min-w-44">
              <Phone size={18} className="mr-2" />
              (555) 123-4567
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactCta;