import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { ChevronRight } from 'lucide-react';
import Section from '../ui/Section';
import { projects } from '../../data/projects';

const FeaturedProjects: React.FC = () => {
  const [activeProject, setActiveProject] = useState(0);
  const featuredProjects = projects.slice(0, 3);

  return (
    <Section
      id="projects"
      title="Featured Projects"
      subtitle="Take a look at some of our recent landscaping transformations."
      dark={true}
    >
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        <div className="relative h-[400px] lg:h-full min-h-[400px]">
          <div className="absolute inset-0 transition-opacity duration-500 z-10 bg-gray-900 bg-opacity-20 rounded-xl overflow-hidden">
            <img
              src={featuredProjects[activeProject].imageAfter}
              alt={featuredProjects[activeProject].title}
              className="w-full h-full object-cover"
            />
            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black to-transparent p-6">
              <h3 className="text-xl font-bold text-white">
                {featuredProjects[activeProject].title}
              </h3>
              <p className="text-gray-300 mt-2">
                {featuredProjects[activeProject].description}
              </p>
            </div>
          </div>
          
          <div className="absolute bottom-4 left-4 z-20 flex space-x-2">
            <span className="text-xs text-white bg-green-700 px-3 py-1 rounded-full">
              After
            </span>
          </div>
          
          <div className="absolute -bottom-6 -right-6 z-20 h-24 w-24">
            <div className="relative w-full h-full">
              <img
                src={featuredProjects[activeProject].imageBefore}
                alt="Before"
                className="w-full h-full object-cover rounded-lg shadow-lg border-2 border-white"
              />
              <div className="absolute top-0 right-0 bg-amber-600 text-white px-2 py-1 text-xs">
                Before
              </div>
            </div>
          </div>
        </div>
        
        <div>
          <h3 className="text-2xl font-bold text-white mb-6">
            Our Transformation Process
          </h3>
          
          <div className="space-y-6">
            <div 
              className={`p-6 rounded-lg transition-all cursor-pointer ${
                activeProject === 0 
                  ? 'bg-green-700 text-white' 
                  : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
              }`}
              onClick={() => setActiveProject(0)}
            >
              <h4 className="font-bold text-lg mb-2">
                {projects[0].title}
              </h4>
              <p className={activeProject === 0 ? 'text-gray-100' : 'text-gray-400'}>
                {projects[0].description}
              </p>
            </div>
            
            <div 
              className={`p-6 rounded-lg transition-all cursor-pointer ${
                activeProject === 1 
                  ? 'bg-green-700 text-white' 
                  : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
              }`}
              onClick={() => setActiveProject(1)}
            >
              <h4 className="font-bold text-lg mb-2">
                {projects[1].title}
              </h4>
              <p className={activeProject === 1 ? 'text-gray-100' : 'text-gray-400'}>
                {projects[1].description}
              </p>
            </div>
            
            <div 
              className={`p-6 rounded-lg transition-all cursor-pointer ${
                activeProject === 2 
                  ? 'bg-green-700 text-white' 
                  : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
              }`}
              onClick={() => setActiveProject(2)}
            >
              <h4 className="font-bold text-lg mb-2">
                {projects[2].title}
              </h4>
              <p className={activeProject === 2 ? 'text-gray-100' : 'text-gray-400'}>
                {projects[2].description}
              </p>
            </div>
          </div>
          
          <div className="mt-8">
            <Link
              to="/portfolio"
              className="inline-flex items-center px-6 py-3 bg-white text-green-800 rounded-md hover:bg-gray-100 transition-colors font-medium"
            >
              View All Projects
              <ChevronRight size={16} className="ml-1" />
            </Link>
          </div>
        </div>
      </div>
    </Section>
  );
};

export default FeaturedProjects;