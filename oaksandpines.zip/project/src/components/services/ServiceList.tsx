import React from 'react';
import { Link } from 'react-router-dom';
import { Flower, Palette, Hammer, Scissors, Wind, Droplets } from 'lucide-react';
import Section from '../ui/Section';
import Button from '../ui/Button';
import { services } from '../../data/services';

const iconMap: { [key: string]: React.ReactNode } = {
  'palette': <Palette size={48} className="text-green-700" />,
  'flower': <Flower size={48} className="text-green-700" />,
  'scissors': <Scissors size={48} className="text-green-700" />,
  'hammer': <Hammer size={48} className="text-green-700" />,
  'droplets': <Droplets size={48} className="text-green-700" />,
  'wind': <Wind size={48} className="text-green-700" />,
};

const ServiceList: React.FC = () => {
  return (
    <Section>
      {services.map((service, index) => (
        <div
          key={service.id}
          id={service.id}
          className={`py-16 ${index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}`}
        >
          <div className="container mx-auto px-4">
            <div className={`grid grid-cols-1 lg:grid-cols-2 gap-12 items-center ${index % 2 === 1 ? 'lg:flex-row-reverse' : ''}`}>
              <div className="order-2 lg:order-none">
                <div className="flex items-center mb-4">
                  {iconMap[service.icon]}
                  <h2 className="text-3xl font-bold ml-4">{service.title}</h2>
                </div>
                <p className="text-gray-600 mb-6 text-lg">
                  {service.description}
                </p>
                <div className="mb-8">
                  <h3 className="font-semibold text-lg mb-3">What's included:</h3>
                  <ul className="space-y-2">
                    <li className="flex items-start">
                      <span className="text-green-700 mr-2">✓</span>
                      <span>Professional consultation and design planning</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-green-700 mr-2">✓</span>
                      <span>Expert implementation by our skilled team</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-green-700 mr-2">✓</span>
                      <span>Quality materials and sustainable practices</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-green-700 mr-2">✓</span>
                      <span>Ongoing support and maintenance options</span>
                    </li>
                  </ul>
                </div>
                <Link to="/booking">
                  <Button variant="primary">Get a Quote</Button>
                </Link>
              </div>
              
              <div className="order-1 lg:order-none">
                <img
                  src={service.image}
                  alt={service.title}
                  className="w-full h-auto rounded-lg shadow-lg"
                />
              </div>
            </div>
          </div>
        </div>
      ))}
    </Section>
  );
};

export default ServiceList;