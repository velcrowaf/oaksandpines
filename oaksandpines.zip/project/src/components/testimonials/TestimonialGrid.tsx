import React from 'react';
import { Quote } from 'lucide-react';
import Section from '../ui/Section';
import { testimonials } from '../../data/testimonials';

const TestimonialGrid: React.FC = () => {
  return (
    <Section>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {testimonials.map((testimonial) => (
          <div
            key={testimonial.id}
            className="bg-white rounded-lg shadow-md p-8 relative"
          >
            <div className="absolute top-6 right-6 text-green-100">
              <Quote size={48} />
            </div>
            
            <div className="flex items-start mb-6">
              <img
                src={testimonial.avatar}
                alt={testimonial.name}
                className="w-16 h-16 rounded-full object-cover mr-4"
              />
              <div>
                <h3 className="font-bold text-lg">{testimonial.name}</h3>
                <p className="text-gray-600">{testimonial.role}</p>
              </div>
            </div>
            
            <p className="text-gray-700 mb-4 relative z-10">
              "{testimonial.content}"
            </p>
            
            <div className="flex">
              {[1, 2, 3, 4, 5].map((star) => (
                <svg
                  key={star}
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 24 24"
                  fill="currentColor"
                  className="w-5 h-5 text-amber-500"
                >
                  <path
                    fillRule="evenodd"
                    d="M10.788 3.21c.448-1.077 1.976-1.077 2.424 0l2.082 5.007 5.404.433c1.164.093 1.636 1.545.749 2.305l-4.117 3.527 1.257 5.273c.271 1.136-.964 2.033-1.96 1.425L12 18.354 7.373 21.18c-.996.608-2.231-.29-1.96-1.425l1.257-5.273-4.117-3.527c-.887-.76-.415-2.212.749-2.305l5.404-.433 2.082-5.006z"
                    clipRule="evenodd"
                  />
                </svg>
              ))}
            </div>
          </div>
        ))}
      </div>
      
      <div className="mt-16 bg-gray-50 rounded-lg p-8 text-center">
        <h3 className="text-2xl font-bold mb-6">Share Your Experience</h3>
        <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
          We value your feedback! If you've worked with us, we'd love to hear about your experience.
          Your testimonial helps others learn about our services.
        </p>
        <a
          href="mailto:reviews@oaksandpines.com"
          className="inline-flex items-center px-6 py-3 bg-green-700 text-white rounded-md hover:bg-green-800 transition-colors"
        >
          Submit Your Testimonial
        </a>
      </div>
    </Section>
  );
};

export default TestimonialGrid;