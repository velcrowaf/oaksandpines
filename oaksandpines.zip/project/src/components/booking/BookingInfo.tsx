import React from 'react';
import { CheckSquare, HelpCircle, CreditCard } from 'lucide-react';

const BookingInfo: React.FC = () => {
  return (
    <div className="space-y-8">
      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="flex items-start">
          <div className="bg-green-100 p-2 rounded-full text-green-700 mr-4 flex-shrink-0">
            <CheckSquare size={24} />
          </div>
          <div>
            <h3 className="text-xl font-bold mb-2">What to Expect</h3>
            <p className="text-gray-600 mb-4">
              Your free consultation is the first step toward creating your dream landscape. Here's what happens next:
            </p>
            <ol className="space-y-2 text-gray-600 list-decimal list-inside">
              <li>We'll contact you to confirm your appointment within 24 hours</li>
              <li>Our landscape specialist will visit your property at the scheduled time</li>
              <li>We'll discuss your vision, needs, and budget</li>
              <li>You'll receive a detailed proposal within 3-5 business days</li>
            </ol>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="flex items-start">
          <div className="bg-green-100 p-2 rounded-full text-green-700 mr-4 flex-shrink-0">
            <HelpCircle size={24} />
          </div>
          <div>
            <h3 className="text-xl font-bold mb-2">Frequently Asked Questions</h3>
            
            <div className="space-y-4 mt-4">
              <div>
                <h4 className="font-semibold text-gray-800">How long does a consultation take?</h4>
                <p className="text-gray-600">
                  Most consultations take 45-60 minutes, depending on the size and complexity of your property.
                </p>
              </div>
              
              <div>
                <h4 className="font-semibold text-gray-800">Is there a fee for the consultation?</h4>
                <p className="text-gray-600">
                  No, initial consultations are completely free with no obligation.
                </p>
              </div>
              
              <div>
                <h4 className="font-semibold text-gray-800">What should I prepare for the consultation?</h4>
                <p className="text-gray-600">
                  Having ideas of what you like, any problem areas, and a rough budget range will help us provide the most useful consultation.
                </p>
              </div>
              
              <div>
                <h4 className="font-semibold text-gray-800">How soon can you start after approval?</h4>
                <p className="text-gray-600">
                  Our project start times vary by season. During your consultation, we'll provide an estimated timeline based on our current schedule.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="flex items-start">
          <div className="bg-green-100 p-2 rounded-full text-green-700 mr-4 flex-shrink-0">
            <CreditCard size={24} />
          </div>
          <div>
            <h3 className="text-xl font-bold mb-2">Payment Information</h3>
            <p className="text-gray-600 mb-4">
              We offer flexible payment options to make your landscaping project accessible:
            </p>
            <ul className="space-y-2 text-gray-600">
              <li className="flex items-start">
                <span className="text-green-700 mr-2">✓</span>
                <span>No payment due until project approval</span>
              </li>
              <li className="flex items-start">
                <span className="text-green-700 mr-2">✓</span>
                <span>50% deposit required to secure your place in our schedule</span>
              </li>
              <li className="flex items-start">
                <span className="text-green-700 mr-2">✓</span>
                <span>Remaining balance due upon project completion</span>
              </li>
              <li className="flex items-start">
                <span className="text-green-700 mr-2">✓</span>
                <span>We accept major credit cards, checks, and electronic transfers</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BookingInfo;