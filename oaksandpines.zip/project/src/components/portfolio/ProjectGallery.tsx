import React, { useState } from 'react';
import Section from '../ui/Section';
import { projects } from '../../data/projects';

const ProjectGallery: React.FC = () => {
  const [filter, setFilter] = useState('All');
  const categories = ['All', ...new Set(projects.map(project => project.category))];

  const filteredProjects = filter === 'All' 
    ? projects 
    : projects.filter(project => project.category === filter);

  return (
    <Section>
      {/* Filter Buttons */}
      <div className="flex flex-wrap justify-center mb-12 gap-2">
        {categories.map(category => (
          <button
            key={category}
            onClick={() => setFilter(category)}
            className={`px-4 py-2 rounded-full transition-colors ${
              filter === category
                ? 'bg-green-700 text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            {category}
          </button>
        ))}
      </div>

      {/* Projects Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {filteredProjects.map(project => (
          <div
            key={project.id}
            className="bg-white rounded-lg shadow-md overflow-hidden group"
          >
            <div className="relative aspect-video overflow-hidden">
              <img
                src={project.imageAfter}
                alt={`${project.title} - After`}
                className="w-full h-full object-cover transition-transform group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-30 transition-opacity flex items-center justify-center opacity-0 group-hover:opacity-100">
                <div className="transform translate-y-4 group-hover:translate-y-0 transition-transform">
                  <div className="bg-white bg-opacity-90 text-green-700 px-4 py-2 rounded-full font-bold">
                    View Project
                  </div>
                </div>
              </div>
              <div className="absolute bottom-4 right-4">
                <span className="bg-green-700 text-white px-3 py-1 rounded-full text-sm">
                  {project.category}
                </span>
              </div>
            </div>
            <div className="p-6">
              <h3 className="text-xl font-bold mb-2">{project.title}</h3>
              <p className="text-gray-600">{project.description}</p>
              
              <div className="mt-4 flex items-center space-x-4">
                <div className="relative h-16 w-16 border-2 border-white rounded shadow-sm">
                  <img
                    src={project.imageBefore}
                    alt={`${project.title} - Before`}
                    className="h-full w-full object-cover"
                  />
                  <span className="absolute top-0 left-0 bg-gray-800 text-white text-xs px-1 py-px">
                    Before
                  </span>
                </div>
                <div className="relative h-16 w-16 border-2 border-white rounded shadow-sm">
                  <img
                    src={project.imageAfter}
                    alt={`${project.title} - After`}
                    className="h-full w-full object-cover"
                  />
                  <span className="absolute top-0 left-0 bg-green-700 text-white text-xs px-1 py-px">
                    After
                  </span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </Section>
  );
};

export default ProjectGallery;