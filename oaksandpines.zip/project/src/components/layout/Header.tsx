import React, { useState, useEffect } from 'react';
import { Menu, X, Trees } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';
import Button from '../ui/Button';

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const location = useLocation();

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 50) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  useEffect(() => {
    // Close menu when route changes
    setIsMenuOpen(false);
  }, [location]);

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'Services', path: '/services' },
    { name: 'Portfolio', path: '/portfolio' },
    { name: 'Testimonials', path: '/testimonials' },
    { name: 'Contact', path: '/contact' },
  ];

  const headerClasses = `fixed w-full z-30 transition-all duration-300 ${
    isScrolled ? 'bg-white shadow-lg py-2' : 'bg-transparent py-4'
  }`;

  const linkClasses = `font-medium transition-colors hover:text-green-700 ${
    isScrolled ? 'text-gray-800' : 'text-white'
  }`;

  return (
    <header className={headerClasses}>
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between">
          <Link to="/" className="flex items-center space-x-2">
            <Trees size={32} className={isScrolled ? 'text-green-700' : 'text-white'} />
            <span className={`text-xl font-bold ${isScrolled ? 'text-gray-800' : 'text-white'}`}>
              Oaks And Pines
            </span>
          </Link>

          {/* Desktop Menu */}
          <nav className="hidden md:flex items-center space-x-8">
            {navLinks.map((link) => (
              <Link
                key={link.name}
                to={link.path}
                className={`${linkClasses} ${
                  location.pathname === link.path ? 'text-green-600 font-semibold' : ''
                }`}
              >
                {link.name}
              </Link>
            ))}
            <Link to="/booking">
              <Button variant="primary">Book Consultation</Button>
            </Link>
          </nav>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden text-gray-600 focus:outline-none"
            onClick={toggleMenu}
            aria-label="Toggle menu"
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} className={isScrolled ? 'text-gray-800' : 'text-white'} />}
          </button>
        </div>

        {/* Mobile Menu */}
        <div
          className={`md:hidden absolute left-0 right-0 top-full bg-white shadow-lg transition-transform duration-300 ease-in-out ${
            isMenuOpen ? 'transform translate-y-0' : 'transform -translate-y-full opacity-0 pointer-events-none'
          }`}
        >
          <nav className="flex flex-col py-4 px-4">
            {navLinks.map((link) => (
              <Link
                key={link.name}
                to={link.path}
                className={`py-3 text-gray-800 font-medium transition-colors hover:text-green-700 ${
                  location.pathname === link.path ? 'text-green-600 font-semibold' : ''
                }`}
              >
                {link.name}
              </Link>
            ))}
            <Link to="/booking" className="mt-4">
              <Button variant="primary" className="w-full">
                Book Consultation
              </Button>
            </Link>
          </nav>
        </div>
      </div>
    </header>
  );
};

export default Header;