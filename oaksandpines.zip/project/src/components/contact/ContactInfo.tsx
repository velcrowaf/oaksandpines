import React from 'react';
import { MapPin, Phone, Mail, Clock } from 'lucide-react';

const ContactInfo: React.FC = () => {
  return (
    <div className="bg-white rounded-lg shadow-md p-8">
      <h3 className="text-xl font-bold mb-6 text-green-700">
        Get In Touch
      </h3>
      
      <div className="space-y-6">
        <div className="flex items-start">
          <div className="bg-green-100 p-2 rounded-full text-green-700 mr-4">
            <MapPin size={20} />
          </div>
          <div>
            <h4 className="font-semibold mb-1">Our Location</h4>
            <p className="text-gray-600">
              Oaks And Pines Landscaping Ltd<br />
              Kimbo, Ruiru<br />
              VWRV+F9 Ruiru
            </p>
          </div>
        </div>
        
        <div className="flex items-start">
          <div className="bg-green-100 p-2 rounded-full text-green-700 mr-4">
            <Phone size={20} />
          </div>
          <div>
            <h4 className="font-semibold mb-1">Phone Number</h4>
            <p className="text-gray-600">
              <a href="tel:+254722263131" className="hover:text-green-700 transition-colors">
                0722 263131
              </a>
            </p>
          </div>
        </div>
        
        <div className="flex items-start">
          <div className="bg-green-100 p-2 rounded-full text-green-700 mr-4">
            <Mail size={20} />
          </div>
          <div>
            <h4 className="font-semibold mb-1">Email Address</h4>
            <p className="text-gray-600">
              <a href="mailto:info@oaksandpines.co.ke" className="hover:text-green-700 transition-colors">
                info@oaksandpines.co.ke
              </a>
            </p>
          </div>
        </div>
        
        <div className="flex items-start">
          <div className="bg-green-100 p-2 rounded-full text-green-700 mr-4">
            <Clock size={20} />
          </div>
          <div>
            <h4 className="font-semibold mb-1">Business Hours</h4>
            <ul className="text-gray-600">
              <li className="flex justify-between">
                <span>Monday - Friday:</span>
                <span>8:00 AM - 5:00 PM</span>
              </li>
              <li className="flex justify-between">
                <span>Saturday:</span>
                <span>9:00 AM - 5:00 PM</span>
              </li>
              <li className="flex justify-between">
                <span>Sunday:</span>
                <span>Closed</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
      
      <div className="mt-8">
        <h3 className="text-xl font-bold mb-4 text-green-700">
          Follow Us
        </h3>
        <div className="flex space-x-4">
          <a
            href="https://facebook.com/oaksandpineskenya"
            className="bg-gray-100 hover:bg-green-100 transition-colors p-2 rounded-full text-gray-600 hover:text-green-700"
            aria-label="Facebook"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path>
            </svg>
          </a>
          <a
            href="https://instagram.com/oaksandpineskenya"
            className="bg-gray-100 hover:bg-green-100 transition-colors p-2 rounded-full text-gray-600 hover:text-green-700"
            aria-label="Instagram"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect>
              <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path>
              <line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line>
            </svg>
          </a>
          <a
            href="https://twitter.com/oaksandpinesKE"
            className="bg-gray-100 hover:bg-green-100 transition-colors p-2 rounded-full text-gray-600 hover:text-green-700"
            aria-label="Twitter"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M22 4c-1 .5-2.16.9-3.5 1.1-1.12-1.2-2.8-1.9-4.5-1.9-3.42 0-6.17 2.75-6.17 6.17 0 .5.06.97.17 1.43A14.7 14.7 0 0 1 2 5c-.5.9-.8 2-.8 3.08 0 2.14 1.1 4.02 2.75 5.13-.62-.01-1.2-.19-1.7-.47v.05c0 2.98 2.14 5.48 4.96 6.05-.52.14-1.06.17-1.63.06.8 2.44 3.1 4.22 5.83 4.27-2.13 1.67-4.84 2.67-7.77 2.67-.5 0-1-.03-1.48-.09A19.88 19.88 0 0 0 12 22c7.64 0 11.8-6.3 11.8-11.8 0-.18 0-.36-.01-.54.8-.58 1.5-1.3 2.05-2.13-.75.34-1.55.57-2.4.67A4.8 4.8 0 0 0 22 4"></path>
            </svg>
          </a>
        </div>
      </div>
    </div>
  );
};

export default ContactInfo;