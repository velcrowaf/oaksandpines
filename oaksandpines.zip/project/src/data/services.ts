import { Service } from '../types';

export const services: Service[] = [
  {
    id: '1',
    title: 'Landscape Design',
    description: 'Professional landscape design services to transform your outdoor space. We create beautiful, functional spaces tailored to your needs and preferences.',
    icon: 'palette',
    image: 'https://images.pexels.com/photos/69776/tulips-bed-colorful-color-69776.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: '2',
    title: 'Garden Installation',
    description: 'Expert garden installation services including plant selection, soil preparation, and planting. We create stunning gardens that thrive in your local environment.',
    icon: 'flower',
    image: 'https://images.pexels.com/photos/6231870/pexels-photo-6231870.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: '3',
    title: 'Lawn Care & Maintenance',
    description: 'Comprehensive lawn care services including mowing, fertilization, aeration, and weed control. Keep your lawn looking its best year-round.',
    icon: 'scissors',
    image: 'https://images.pexels.com/photos/589/garden-grass-lawn-meadow.jpg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: '4',
    title: 'Hardscaping',
    description: 'Custom hardscaping solutions including patios, walkways, retaining walls, and outdoor kitchens. Enhance your outdoor living space with durable, beautiful hardscape elements.',
    icon: 'hammer',
    image: 'https://images.pexels.com/photos/17492749/pexels-photo-17492749/free-photo-of-paved-garden-path.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: '5',
    title: 'Irrigation Systems',
    description: 'Efficient irrigation system design, installation, and maintenance. Save water while keeping your landscape healthy and vibrant.',
    icon: 'droplets',
    image: 'https://images.pexels.com/photos/2980937/pexels-photo-2980937.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: '6',
    title: 'Seasonal Cleanup',
    description: 'Thorough seasonal cleanup services to prepare your landscape for the changing seasons. Includes leaf removal, pruning, and debris cleanup.',
    icon: 'wind',
    image: 'https://images.pexels.com/photos/5797997/pexels-photo-5797997.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  }
];