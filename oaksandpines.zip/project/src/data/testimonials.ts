import { Testimonial } from '../types';

export const testimonials: Testimonial[] = [
  {
    id: '1',
    name: 'Sarah Johnson',
    role: 'Homeowner',
    content: 'Oaks And Pines transformed our backyard into a beautiful, functional space that we use year-round. Their attention to detail and customer service was outstanding from start to finish.',
    avatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: '2',
    name: 'Michael Chen',
    role: 'Business Owner',
    content: 'We hired Oaks And Pines to landscape our new office building, and they exceeded our expectations. Their team was professional, efficient, and delivered a stunning result on time and within budget.',
    avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: '3',
    name: 'Emily Rodriguez',
    role: 'Real Estate Agent',
    content: 'I recommend Oaks And Pines to all my clients looking to improve their property value through landscaping. Their design expertise and quality workmanship make a noticeable difference.',
    avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: '4',
    name: 'David Thompson',
    role: 'Homeowner',
    content: 'The team at Oaks And Pines helped us create a low-maintenance landscape that still looks beautiful. Five years later, we\'re still enjoying their expert design and quality plants.',
    avatar: 'https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  }
];