import { Project } from '../types';

export const projects: Project[] = [
  {
    id: '1',
    title: 'Modern Backyard Transformation',
    description: 'Complete backyard redesign including custom patio, fire pit, and native plant garden.',
    category: 'Garden Design',
    imageBefore: 'https://images.pexels.com/photos/280222/pexels-photo-280222.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    imageAfter: 'https://images.pexels.com/photos/1650675/pexels-photo-1650675.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: '2',
    title: 'Commercial Property Landscaping',
    description: 'Professional landscaping for a commercial office building featuring drought-resistant plants and efficient irrigation.',
    category: 'Commercial',
    imageBefore: 'https://images.pexels.com/photos/13908533/pexels-photo-13908533.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    imageAfter: 'https://images.pexels.com/photos/2082162/pexels-photo-2082162.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: '3',
    title: 'Elegant Front Yard Makeover',
    description: 'Front yard redesign featuring curved walkways, layered plantings, and accent lighting.',
    category: 'Residential',
    imageBefore: 'https://images.pexels.com/photos/1290735/pexels-photo-1290735.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    imageAfter: 'https://images.pexels.com/photos/5997993/pexels-photo-5997993.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: '4',
    title: 'Sustainable Garden Installation',
    description: 'Eco-friendly garden featuring native plants, rainwater harvesting, and permeable hardscaping.',
    category: 'Garden Design',
    imageBefore: 'https://images.pexels.com/photos/1643774/pexels-photo-1643774.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    imageAfter: 'https://images.pexels.com/photos/462118/pexels-photo-462118.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: '5',
    title: 'Stone Patio & Fire Pit',
    description: 'Custom stone patio with built-in fire pit, seating walls, and integrated landscape lighting.',
    category: 'Hardscaping',
    imageBefore: 'https://images.pexels.com/photos/2307238/pexels-photo-2307238.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    imageAfter: 'https://images.pexels.com/photos/15018191/pexels-photo-15018191/free-photo-of-patio-with-fireplace-in-garden.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: '6',
    title: 'Complete Lawn Renovation',
    description: 'Full lawn renovation including grading, soil amendment, irrigation, and sod installation.',
    category: 'Lawn Care',
    imageBefore: 'https://images.pexels.com/photos/8566395/pexels-photo-8566395.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    imageAfter: 'https://images.pexels.com/photos/347135/pexels-photo-347135.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  }
];