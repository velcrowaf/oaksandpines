export interface Service {
  id: string;
  title: string;
  description: string;
  icon: string;
  image: string;
}

export interface Project {
  id: string;
  title: string;
  description: string;
  category: string;
  imageBefore: string;
  imageAfter: string;
}

export interface Testimonial {
  id: string;
  name: string;
  role: string;
  content: string;
  avatar: string;
}

export interface BookingFormData {
  name: string;
  email: string;
  phone: string;
  address: string;
  service: string;
  message: string;
  date: string;
}