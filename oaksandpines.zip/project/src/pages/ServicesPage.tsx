import React from 'react';
import Layout from '../components/layout/Layout';
import ServiceList from '../components/services/ServiceList';
import ContactCta from '../components/home/ContactCta';

const ServicesPage: React.FC = () => {
  return (
    <Layout>
      <div className="bg-green-700 pt-32 pb-16">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">Our Services</h1>
          <p className="text-xl text-green-100 max-w-2xl mx-auto">
            From design to installation and maintenance, we offer comprehensive landscaping services to meet all your outdoor needs.
          </p>
        </div>
      </div>
      <ServiceList />
      <ContactCta />
    </Layout>
  );
};

export default ServicesPage;