import React from 'react';
import Layout from '../components/layout/Layout';
import ProjectGallery from '../components/portfolio/ProjectGallery';
import ContactCta from '../components/home/ContactCta';

const PortfolioPage: React.FC = () => {
  return (
    <Layout>
      <div className="bg-green-700 pt-32 pb-16">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">Our Portfolio</h1>
          <p className="text-xl text-green-100 max-w-2xl mx-auto">
            Browse our collection of completed landscaping projects and see how we transform outdoor spaces.
          </p>
        </div>
      </div>
      <ProjectGallery />
      <ContactCta />
    </Layout>
  );
};

export default PortfolioPage;