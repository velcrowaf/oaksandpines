import React from 'react';
import Layout from '../components/layout/Layout';
import BookingForm from '../components/booking/BookingForm';
import BookingInfo from '../components/booking/BookingInfo';

const BookingPage: React.FC = () => {
  return (
    <Layout>
      <div className="bg-green-700 pt-32 pb-16">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">Book a Consultation</h1>
          <p className="text-xl text-green-100 max-w-2xl mx-auto">
            Schedule a free, no-obligation consultation with our landscaping experts to discuss your project.
          </p>
        </div>
      </div>

      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <BookingForm />
            </div>
            <div>
              <BookingInfo />
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default BookingPage;