import React from 'react';
import Layout from '../components/layout/Layout';
import Hero from '../components/home/Hero';
import About from '../components/home/About';
import FeaturedServices from '../components/home/FeaturedServices';
import FeaturedProjects from '../components/home/FeaturedProjects';
import FeaturedTestimonials from '../components/home/FeaturedTestimonials';
import ContactCta from '../components/home/ContactCta';

const HomePage: React.FC = () => {
  return (
    <Layout>
      <Hero />
      <About />
      <FeaturedServices />
      <FeaturedProjects />
      <FeaturedTestimonials />
      <ContactCta />
    </Layout>
  );
};

export default HomePage;