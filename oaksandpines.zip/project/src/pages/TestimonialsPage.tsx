import React from 'react';
import Layout from '../components/layout/Layout';
import TestimonialGrid from '../components/testimonials/TestimonialGrid';
import ContactCta from '../components/home/ContactCta';

const TestimonialsPage: React.FC = () => {
  return (
    <Layout>
      <div className="bg-green-700 pt-32 pb-16">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">Testimonials</h1>
          <p className="text-xl text-green-100 max-w-2xl mx-auto">
            Read what our clients have to say about their experience working with Oaks And Pines Landscaping.
          </p>
        </div>
      </div>
      <TestimonialGrid />
      <ContactCta />
    </Layout>
  );
};

export default TestimonialsPage;